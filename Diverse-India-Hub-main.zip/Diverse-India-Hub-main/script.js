function goToCostumes() {
    window.location.href = 'costumes.html';
}
function goToFood() {
    window.location.href = 'food.html';
}
function goToSports() {
    window.location.href = 'sports.html';
}
function goToFestivals() {
    window.location.href = 'festivals.html';
}
function goToLanguages() {
    window.location.href = 'languages.html';
}
function goToTourism() {
    window.location.href = 'tourism.html';
}
function goToCities() {
    window.location.href = 'cities.html';
}
function goToDances() {
    window.location.href = 'dances.html';
}
function goToPolitics() {
    window.location.href = 'politics.html';
}
function goToStates() {
    window.location.href = 'states.html';
}
function goToSongs() {
    window.location.href = 'song.html';
}
function goToReligions() {
    window.location.href = 'religions.html';
}
function goToFeedback() {
    window.location.href = 'feedback.html';
}
function goToSignUp() {
    window.location.href = 'signup.html';
}
function goToLogin() {
    window.location.href = 'login.html';
} 
function goToAboutUs() {
    window.location.href = 'about-us.html';
} 

function scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}

